# This is a simple file management tool.
# User input follows the format of
# command input -option input
# This program currently allows the user to use two commands:
# 1. L - list contents of specified directory
# 2. Q - stop program operation